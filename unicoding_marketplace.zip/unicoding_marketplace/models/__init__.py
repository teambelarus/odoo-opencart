# License AGPL-3 - See http://www.gnu.org/licenses/agpl-3.0.html

from . import unicoding_marketplace
from . import res_partner
from . import sale
from . import crm_lead
from . import product
from . import product_template
from . import product_pricelist
from . import res_config_settings
from . import account_invoice
